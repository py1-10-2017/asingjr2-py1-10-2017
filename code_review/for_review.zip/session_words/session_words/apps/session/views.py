# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render, redirect, HttpResponse
import datetime
import time


# Create your views here.
def index(request):
    print 'home page'
    time = datetime.datetime.now().strftime('%Y, %d, %M, %H')
    context ={
        'time':time
    }
    return render(request, 'session/index.html', context)
    # return HttpResponse('starting')


def submit(request):
    new_word = {}           #Making empty dictionary
    for key, value in request.POST.iteritems():
        print key,value
    #     if key != "csrfmiddlewaretoken" and key != "font":
    #     new_word[key] = value
    # if key == "show-big":
    #     new_word['big'] = "big"
    # else:
    #     new_word['big'] = ""
    # new_word['created_at'] = datetime.now().strftime("%H:%M %p, %B %d, %Y")
    # try:
    #     request.session['words']
    # except KeyError:
    #     request.session['words'] = []

    # temp_list = request.session['words']
    # temp_list.append(new_word)
    # request.session['words'] = temp_list
    # for key, val in request.session.__dict__.iteritems():
    #     print key, val
    # print "past created at", new_word
    return redirect('/')
    # if 'word' not in request.session['name']:
    #     request.session['name'] = request.POST['name']
    #     request.session['color'] = request.POST['color']
    #     request.session['font'] = request.POST['font']
    #     request.session['time'] = time
    #     request.session['time2'] = request.POST['time']
    # else:
    #     request.session
    return redirect(' ')

def clear(request):
    print 'clear page'
    print request.session
    for key in request.session.keys():
        del request.session[key] 
    return HttpResponse('clear')

def test(request):
    return HttpResponse('TEST PAGE')
