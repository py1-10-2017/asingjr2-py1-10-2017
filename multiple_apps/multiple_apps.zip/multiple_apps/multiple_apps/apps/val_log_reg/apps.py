# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class ValLogRegConfig(AppConfig):
    name = 'val_log_reg'
