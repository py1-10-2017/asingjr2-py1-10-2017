from flask import Flask, session, redirect, request, render_template
import os 
import random  

app = Flask(__name__)
app.secret_key = os.urandom(32)

@app.route('/')
def start():
    print('Hello Moto')
    if 'gold' not in session:
        session['gold']=0
        session['updates']=[]
        return render_template("ninja_gold.html", gold=session['gold'], updates=session['updates'])
   
@app.route('/process_money', methods=['POST'])
def process():
    building= request.form['building']
    if building == 'farm':
        gold = random.randrange(10,21)
        session['updates'].append("You entered a {} and earned {} golds".format(building, gold))      

    elif building == 'cave':
        gold = random.randrange(5,11)
        session['updates'].append("You entered a {} and earned {} gold".format(building, gold))

    elif building == 'house':
        gold = random.randrange(2,6)
        session['updates'].append("You entered a {}} and earned {} gold".format(building, gold))

    elif building == 'casino':
        gold = random.randrange(-50,51)
        if gold < 0:
            session['updates'].append("You entered a {} and lost{} gold".format(building, gold))
        else:
          session['updates'].append("You entered a {} and earned {} gold".format(building, gold))

    session['gold'] += gold
    return redirect('/')

app.run(debug=True)

